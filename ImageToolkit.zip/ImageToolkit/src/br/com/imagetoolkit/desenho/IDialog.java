/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package br.com.imagetoolkit.desenho;

/**
 *
 * @author 2091140052
 */
public interface IDialog {

    public void alterarBrilho(int brilho);

    public void alterarContraste(int contraste);
}
